package com.example.procurement.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class MouserProductDTO {

    private String manufacturer;
    private String manufacturerPartNumber;
    private String description;
    private String category;
    private String leadTime;
    private String rohsStatus;
    private String productDetailUrl;
    private String availability;
    private String factoryStock;
    private String imagePath;
    private List<MouserProductAttributeDTO> productAttributes;
    private List<MouserPriceBreakDTO> priceBreaks;

    private String purchaseNo;

}

