package com.example.procurement.dto;


import lombok.Data;

@Data
public class MouserProductAttributeDTO {

    private String attributeName;
    private String attributeValue;

}

