package com.example.procurement.controller;

import com.example.procurement.model.Token;
import com.example.procurement.service.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("token")
public class TokenController {

	@Autowired
	private TokenService tokenService;

	@GetMapping("/fetchCredentials")
	public List<Token> fetchCredentials() {
		return tokenService.getAllTiCredentials();
	}

	@PostMapping("/saveToken")
	public Token saveToken(@RequestBody Token tokenCredentials) {
		return tokenService.saveToken(tokenCredentials);  // Save the token to DB
	}

}
