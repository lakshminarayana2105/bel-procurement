package com.example.procurement.repository;

import com.example.procurement.model.MouserPriceBreak;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MouserPriceBreakRepository extends JpaRepository<MouserPriceBreak, Long> {
    // Custom query methods (if needed)
}

