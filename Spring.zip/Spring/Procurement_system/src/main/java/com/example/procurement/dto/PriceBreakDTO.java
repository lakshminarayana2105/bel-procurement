package com.example.procurement.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PriceBreakDTO {

    private Integer priceBreakQuantity;
    private Double price;
}
