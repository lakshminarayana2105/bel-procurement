package com.example.procurement.model;

import lombok.Data;

import jakarta.persistence.*;

@Data
@Entity
public class MouserProductAttribute {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String attributeName;
    private String attributeValue;

    @ManyToOne
    @JoinColumn(name = "mouser_product_id")
    private MouserProduct mouserProduct;
}
