package com.example.procurement.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@Entity
@Table(name = "products")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @Column(unique = true)
    private String tiPartNumber;
    private String genericPartNumber;
    private String buyNowUrl;
    private Integer quantity;
    private String description;
    private Integer minimumOrderQuantity;
    private Integer standardPackQuantity;
    private String exportControlClassificationNumber;
    private String htsCode;
    private Integer pinCount;
    private String packageType;
    private String packageCarrier;
    private Boolean customReel;
    private String lifeCycle;

    // Cascade all operations to Pricing (including saving Pricing and PriceBreakEntity
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<Pricing> pricing;

    private String purchaseNo;

}
