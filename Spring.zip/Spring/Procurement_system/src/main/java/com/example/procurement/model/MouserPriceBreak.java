package com.example.procurement.model;

import lombok.Data;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Data
@Entity
public class MouserPriceBreak {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int quantity;
    private BigDecimal price;
    private String currency;

    @ManyToOne
    @JoinColumn(name = "mouser_product_id")
    private MouserProduct mouserProduct;
}
