package com.example.procurement.repository;


import com.example.procurement.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    Product findByTiPartNumber(String partNumber);

    Product findByPurchaseNo(String purchaseNo);

//    Product getByPurchaseNo(String purchaseNo);
}

