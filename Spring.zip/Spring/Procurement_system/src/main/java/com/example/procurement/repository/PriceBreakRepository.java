package com.example.procurement.repository;

import com.example.procurement.model.PriceBreakEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface PriceBreakRepository extends JpaRepository<PriceBreakEntity, Long> {
}
