package com.example.procurement.dto;


import com.example.procurement.model.MouserProduct;
import com.example.procurement.model.Product;
import lombok.Data;

@Data
public class L1Dto {
    private MouserProduct mouserProduct;
    private Product product;
    private Integer rank;
}
