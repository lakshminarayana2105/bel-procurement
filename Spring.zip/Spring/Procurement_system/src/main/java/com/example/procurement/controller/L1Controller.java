package com.example.procurement.controller;


import com.example.procurement.dto.L1Dto;
import com.example.procurement.service.L1Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/L1")
public class L1Controller {

    @Autowired
    L1Service l1Service;

    @GetMapping("/getL1/{purchase_no}/{quantity}")
    public L1Dto getL1(@RequestParam String purchase_no, Integer quantity) {

        return l1Service.l1Details(purchase_no, quantity);
        
    }
}
