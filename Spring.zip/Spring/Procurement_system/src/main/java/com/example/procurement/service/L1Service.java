package com.example.procurement.service;


import com.example.procurement.dto.L1Dto;
import com.example.procurement.model.MouserProduct;
import com.example.procurement.model.PriceBreakEntity;
import com.example.procurement.model.Pricing;
import com.example.procurement.model.Product;
import com.example.procurement.repository.MouserProductRepository;
import com.example.procurement.repository.PriceBreakRepository;
import com.example.procurement.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class L1Service {


    @Autowired
    ProductRepository productRepository;

    @Autowired
    MouserProductRepository mouserProductRepository;


    public L1Dto l1Details(String purchaseNo, Integer quantity) {
        Product product = productRepository.findByPurchaseNo(purchaseNo);

        MouserProduct mouserProduct = mouserProductRepository.findByPurchaseNo(purchaseNo);

        List<Pricing> prices = product.getPricing();

        System.out.println(prices);

        for(Pricing price: prices){
            System.out.println(price.getPriceBreaks());
        }



        L1Dto l1Dto = new L1Dto();

        l1Dto.setProduct(product);
        l1Dto.setMouserProduct(mouserProduct);

        return l1Dto;

    }
}
