package com.example.procurement.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@Entity
@Table(name = "pricing")
public class Pricing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String currency;

    // Relationship with PriceBreakEntity: Pricing has multiple price breaks
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "pricing_id") // The foreign key in PriceBreakEntity table
    private List<PriceBreakEntity> priceBreaks;

    // Relationship with Product: A pricing belongs to one product
    @ManyToOne
    @JoinColumn(name = "product_id") // Foreign key in pricing table
    private Product product;

}
