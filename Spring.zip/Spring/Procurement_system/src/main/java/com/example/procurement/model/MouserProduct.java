package com.example.procurement.model;

import lombok.Data;

import jakarta.persistence.*;
import java.util.List;

@Data
@Entity
public class MouserProduct {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String manufacturer;

    @Column(unique = true)
    private String manufacturerPartNumber;
    private String description;
    private String category;
    private String leadTime;
    private String rohsStatus;
    private String productDetailUrl;
    private String availability;
    private String factoryStock;
    private String imagePath;

    @OneToMany(mappedBy = "mouserProduct", cascade = CascadeType.ALL)
    private List<MouserProductAttribute> productAttributes;

    @OneToMany(mappedBy = "mouserProduct", cascade = CascadeType.ALL)
    private List<MouserPriceBreak> priceBreaks;


    private String purchaseNo;
}
