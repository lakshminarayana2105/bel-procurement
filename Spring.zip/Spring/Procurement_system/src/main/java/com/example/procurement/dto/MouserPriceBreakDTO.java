package com.example.procurement.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class MouserPriceBreakDTO {

    private int quantity;
    private BigDecimal price;
    private String currency;

}

