package com.example.procurement.service;

import com.example.procurement.dto.MouserProductDTO;
import com.example.procurement.dto.MouserPriceBreakDTO;
import com.example.procurement.dto.MouserProductAttributeDTO;
import com.example.procurement.model.MouserProduct;
import com.example.procurement.model.MouserPriceBreak;
import com.example.procurement.model.MouserProductAttribute;
import com.example.procurement.repository.MouserProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MouserProductService {

    @Autowired
    private MouserProductRepository mouserProductRepository;

    // Method to save a product along with its price breaks and attributes
    @Transactional
    public MouserProduct saveMouserProduct(MouserProduct mouserProduct) {
        // Set the product reference in each price break and attribute
        for (MouserPriceBreak priceBreak : mouserProduct.getPriceBreaks()) {
            priceBreak.setMouserProduct(mouserProduct);
        }

        for (MouserProductAttribute attribute : mouserProduct.getProductAttributes()) {
            attribute.setMouserProduct(mouserProduct);
        }

        // Save the product along with its price breaks and attributes
        return mouserProductRepository.save(mouserProduct);
    }

    // Method to fetch the product by part number
    public MouserProduct fetchProductByPartNumber(String partNumber) {
        return mouserProductRepository.findByManufacturerPartNumber(partNumber);
    }

    // Method to map the product entity to the DTO
    public MouserProductDTO mapToMouserProductDTO(MouserProduct product) {
        MouserProductDTO productDTO = new MouserProductDTO();
        productDTO.setManufacturer(product.getManufacturer());
        productDTO.setManufacturerPartNumber(product.getManufacturerPartNumber());
        productDTO.setDescription(product.getDescription());
        productDTO.setCategory(product.getCategory());
        productDTO.setLeadTime(product.getLeadTime());
        productDTO.setRohsStatus(product.getRohsStatus());
        productDTO.setProductDetailUrl(product.getProductDetailUrl());
        productDTO.setAvailability(product.getAvailability());
        productDTO.setFactoryStock(product.getFactoryStock());
        productDTO.setImagePath(product.getImagePath());
        productDTO.setPurchaseNo(product.getPurchaseNo());

        // Map product attributes (if any)
        List<MouserProductAttributeDTO> productAttributes = product.getProductAttributes().stream()
                .map(this::mapToMouserProductAttributeDTO)
                .collect(Collectors.toList());
        productDTO.setProductAttributes(productAttributes);

        // Map price breaks (if any)
        List<MouserPriceBreakDTO> priceBreaks = product.getPriceBreaks().stream()
                .map(this::mapToMouserPriceBreakDTO)
                .collect(Collectors.toList());
        productDTO.setPriceBreaks(priceBreaks);

        return productDTO;
    }

    // Helper method to map a MouserProductAttribute entity to a DTO
    private MouserProductAttributeDTO mapToMouserProductAttributeDTO(MouserProductAttribute attribute) {
        MouserProductAttributeDTO attributeDTO = new MouserProductAttributeDTO();
        attributeDTO.setAttributeName(attribute.getAttributeName());
        attributeDTO.setAttributeValue(attribute.getAttributeValue());
        return attributeDTO;
    }

    // Helper method to map a MouserPriceBreak entity to a DTO
    private MouserPriceBreakDTO mapToMouserPriceBreakDTO(MouserPriceBreak priceBreak) {
        MouserPriceBreakDTO priceBreakDTO = new MouserPriceBreakDTO();
        priceBreakDTO.setQuantity(priceBreak.getQuantity());
        priceBreakDTO.setPrice(priceBreak.getPrice());
        priceBreakDTO.setCurrency(priceBreak.getCurrency());
        return priceBreakDTO;
    }
}
