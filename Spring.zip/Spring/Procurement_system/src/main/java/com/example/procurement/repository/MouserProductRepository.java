package com.example.procurement.repository;

import com.example.procurement.model.MouserProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MouserProductRepository extends JpaRepository<MouserProduct, Long> {
    MouserProduct findByManufacturerPartNumber(String partNumber);

    MouserProduct findByPurchaseNo(String purchaseNo);
}

