package com.example.procurement.controller;

import com.example.procurement.dto.MouserProductDTO;
import com.example.procurement.dto.ProductDTO;
import com.example.procurement.model.MouserProduct;
import com.example.procurement.model.Product;
import com.example.procurement.service.MouserProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/mouser")
public class MouserProductController {

    @Autowired
    private MouserProductService mouserProductService;


    @PostMapping("/add")
    public MouserProductDTO addProduct(@RequestBody MouserProduct product) {
        MouserProduct savedProduct = mouserProductService.saveMouserProduct(product);
        return mouserProductService.mapToMouserProductDTO(savedProduct);
    }

    @GetMapping("/{partNumber}")
    public MouserProductDTO getProductByPartNumber(@PathVariable String partNumber) {
        // Fetch product by part number and map to DTO
        MouserProduct product = mouserProductService.fetchProductByPartNumber(partNumber);
        return mouserProductService.mapToMouserProductDTO(product);
    }
}

