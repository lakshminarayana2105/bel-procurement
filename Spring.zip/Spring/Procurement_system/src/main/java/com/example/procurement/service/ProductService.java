package com.example.procurement.service;

import com.example.procurement.dto.PriceBreakDTO;
import com.example.procurement.dto.PricingDTO;
import com.example.procurement.dto.ProductDTO;
import com.example.procurement.model.PriceBreakEntity;
import com.example.procurement.model.Pricing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.procurement.model.Product;
import com.example.procurement.repository.ProductRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Transactional
    public Product saveProductWithPricing(Product product) {
        // Set the Product reference in each Pricing entity
        for (Pricing pricing : product.getPricing()) {
            pricing.setProduct(product);

            // Set the product reference in each PriceBreakEntity
            for (PriceBreakEntity priceBreak : pricing.getPriceBreaks()) {
                priceBreak.setPricing(pricing);
            }
        }

        // Save the product and its associated pricing entities
        return productRepository.save(product);
    }

    public Product fetchProductByPartNumber(String partNumber) {
        return productRepository.findByTiPartNumber(partNumber);
    }


    public ProductDTO mapToProductDTO(Product product) {
        ProductDTO productDTO = new ProductDTO();
        productDTO.setTiPartNumber(product.getTiPartNumber());
        productDTO.setGenericPartNumber(product.getGenericPartNumber());
        productDTO.setBuyNowUrl(product.getBuyNowUrl());
        productDTO.setQuantity(product.getQuantity());
        productDTO.setDescription(product.getDescription());
        productDTO.setMinimumOrderQuantity(product.getMinimumOrderQuantity());
        productDTO.setStandardPackQuantity(product.getStandardPackQuantity());
        productDTO.setExportControlClassificationNumber(product.getExportControlClassificationNumber());
        productDTO.setHtsCode(product.getHtsCode());
        productDTO.setPinCount(product.getPinCount());
        productDTO.setPackageType(product.getPackageType());
        productDTO.setPackageCarrier(product.getPackageCarrier());
        productDTO.setCustomReel(product.getCustomReel());
        productDTO.setLifeCycle(product.getLifeCycle());
        productDTO.setPurchaseNo(product.getPurchaseNo());

        // Mapping Pricing entities
        List<PricingDTO> pricingDTOList = product.getPricing().stream().map(this::mapToPricingDTO).collect(Collectors.toList());

        productDTO.setPricing(pricingDTOList);

        return productDTO;
    }

    private PricingDTO mapToPricingDTO(Pricing pricing) {
        PricingDTO pricingDTO = new PricingDTO();
        pricingDTO.setCurrency(pricing.getCurrency());

        // Mapping PriceBreakEntity
        List<PriceBreakDTO> priceBreakDTOList = pricing.getPriceBreaks().stream().map(this::mapToPriceBreakDTO).collect(Collectors.toList());

        pricingDTO.setPriceBreaks(priceBreakDTOList);

        return pricingDTO;
    }

    private PriceBreakDTO mapToPriceBreakDTO(PriceBreakEntity priceBreakEntity) {
        PriceBreakDTO priceBreakDTO = new PriceBreakDTO();
        priceBreakDTO.setPriceBreakQuantity(priceBreakEntity.getPriceBreakQuantity());
        priceBreakDTO.setPrice(priceBreakEntity.getPrice());
        return priceBreakDTO;
    }
}
