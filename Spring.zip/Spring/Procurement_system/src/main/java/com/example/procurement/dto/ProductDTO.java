package com.example.procurement.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ProductDTO {

    private String tiPartNumber;
    private String genericPartNumber;
    private String buyNowUrl;
    private Integer quantity;
    private String description;
    private Integer minimumOrderQuantity;
    private Integer standardPackQuantity;
    private String exportControlClassificationNumber;
    private String htsCode;
    private Integer pinCount;
    private String packageType;
    private String packageCarrier;
    private Boolean customReel;
    private String lifeCycle;
    private List<PricingDTO> pricing;

    private String purchaseNo;

}

