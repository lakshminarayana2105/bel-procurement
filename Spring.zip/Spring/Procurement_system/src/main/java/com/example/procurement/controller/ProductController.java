package com.example.procurement.controller;

import com.example.procurement.dto.ProductDTO;
import com.example.procurement.model.Product;
import com.example.procurement.repository.ProductRepository;
import com.example.procurement.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("*")
@RestController
@RequestMapping("/product")
public class ProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private ProductRepository productRepository;

    @PostMapping("/add")
    public ProductDTO addProduct(@RequestBody Product product) {
        Product savedProduct = productService.saveProductWithPricing(product);
        return productService.mapToProductDTO(savedProduct);
    }

    @GetMapping("/fetch/{partNumber}")
    public ProductDTO getProductByPartNumber(@PathVariable String partNumber) {
        Product product = productService.fetchProductByPartNumber(partNumber);
//        Product product = productRepository.findByPurchaseNo("2103737524");
        return productService.mapToProductDTO(product);

    }
}
