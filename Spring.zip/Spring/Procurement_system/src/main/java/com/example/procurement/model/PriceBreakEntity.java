package com.example.procurement.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "price_breaks")
public class PriceBreakEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Reference to Pricing: PriceBreakEntity belongs to one Pricing
    @ManyToOne
    @JoinColumn(name = "pricing_id") // Foreign key in PriceBreakEntity
    private Pricing pricing;

    private Integer priceBreakQuantity;
    private Double price;


}
