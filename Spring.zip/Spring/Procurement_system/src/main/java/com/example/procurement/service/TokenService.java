package com.example.procurement.service;

import com.example.procurement.model.Token;
import com.example.procurement.repository.TokenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TokenService {

    @Autowired
    private TokenRepository tokenRepository;

    public List<Token> getAllTiCredentials() {

         return tokenRepository.findAll();
    }

    public Token saveToken(Token tokenCredentials) {
        return tokenRepository.save(tokenCredentials);
    }
}
